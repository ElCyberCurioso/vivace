# Iconos Accordio

Rejilla de 24 px, trazo 1.7 px, remates redondeados. El trazo principal usa `currentColor`;
las partes de énfasis leen `--ac-icon-accent` (por defecto coral #FF6B6B).

## Uso con el sprite
```html
<!-- una vez, al inicio del <body> -->
<div hidden>{{ contenido de sprite.svg }}</div>

<svg class="ac-icon" aria-hidden="true"><use href="#ac-chord"></use></svg>
```
```css
.ac-icon{ width:24px; height:24px; color:var(--ac-primary); --ac-icon-accent:var(--ac-coral); }
```

## Inventario
- `guitar-custom.svg`
- `notes.svg`
- `upvote.svg`
- `review.svg`
- `profile.svg`
- `user.svg`
- `chord.svg`
- `chord-types.svg`
- `star.svg`
- `star-outline.svg`
- `plus-circle.svg`
- `home.svg`
- `bell.svg`
- `menu.svg`
- `chevron-right.svg`
- `search.svg`
- `metronome.svg`
- `tab.svg`
- `sheet-music.svg`
- `play-circle.svg`
- `submit.svg`
- `settings.svg`
- `plus.svg`
