# Accordio — paquete de estilo para web

Extraído del board de marca. Todo lo necesario para montar la web: tokens, logotipos, iconos,
patrones, diagramas de acordes e imágenes.

## Instalación

```html
<link rel="stylesheet" href="accordio-web-kit/css/fonts.css">         <!-- Montserrat + Poppins -->
<link rel="stylesheet" href="accordio-web-kit/tokens/tokens.css">     <!-- variables (claro) -->
<link rel="stylesheet" href="accordio-web-kit/tokens/tokens.dark.css"><!-- modo oscuro, DESPUÉS -->
<link rel="stylesheet" href="accordio-web-kit/css/accordio.css">      <!-- componentes .ac-* -->
<script src="accordio-web-kit/js/theme.js"></script>                  <!-- opcional: control manual -->
<link rel="icon" href="accordio-web-kit/logo/favicon.svg">
```

Abre `guide/index.html` en el navegador para ver la guía visual completa, con conmutador de tema.

## Modo claro / modo oscuro

Con las dos hojas de tokens el tema **sigue al sistema** (`prefers-color-scheme`). Añadiendo
`js/theme.js` hay control manual:

```html
<button data-ac-theme-toggle>Tema</button>
```
```js
AccordioTheme.set('dark');  // fija y recuerda
AccordioTheme.toggle();
AccordioTheme.clear();      // vuelve a seguir al sistema
```

El script escribe `data-theme="dark|light"` en `<html>` (gana sobre la media query), guarda la
elección en `localStorage` y lanza el evento `ac-themechange`.

Los recursos con dos versiones se declaran en el propio elemento y el script les cambia el `src`
(o el `background-image` si no es un `<img>`):

```html
<img data-ac-light="…/logo/lockup-horizontal.svg"
     data-ac-dark="…/logo/lockup-horizontal-light.svg" alt="Accordio">
```

Pares disponibles: `logo/lockup-horizontal.svg` ↔ `-light`, `lockup-g-stacked.svg` ↔ `-light`,
`app-icon.svg` ↔ `app-icon-dark.svg`, `favicon.svg` ↔ `favicon-dark.svg`,
`mark-fretboard.svg` ↔ `-light`, `mark-g.svg` ↔ `mark-g-dark.svg`,
`patterns/music-tile.svg` ↔ `-dark`, `hero-band.svg` ↔ `-dark`,
`icons/x.svg` ↔ `icons-dark/x.svg`, `chords/chord-g.svg` ↔ `chord-g-dark.svg`.

Los iconos del `sprite.svg` **no necesitan par**: usan `currentColor` y toman el color del tema.
Las utilidades `.ac-logo` y `.ac-hero-band` ya leen el recurso correcto vía token, sin JS.

### Superficies y roles en oscuro

| Rol | Claro | Oscuro |
| --- | --- | --- |
| Fondo | `#F7EFE3` | `#0F2429` |
| Fondo alterno | `#F3E3CD` | `#122E34` |
| Tarjeta | `#F2FAF6` | `#163A41` |
| Tarjeta elevada | `#FFFFFF` | `#1C464E` |
| Titular / texto / secundario | `#12363D / #3F5257 / #7B8E92` | `#F2FAF6 / #C6DCDE / #8CA6AA` |
| Borde | `#DCE8E5` | `#26545C` |
| Acción (`--ac-action`) | `#1A535C` sobre `#F2FAF6` | `#4ECDC4` sobre `#08262B` |
| Destacado (`--ac-highlight`) | `#FF6B6B` | `#FF8A8A` |
| Barra superior | `#1A535C` | `#0B1D21` |

La marca no se invierte: las cuatro rampas son las mismas. En oscuro el teal deja de ser color de
acción (no contrasta contra el fondo) y pasa a titular; la acción principal la toma el turquesa, y
coral y amarillo suben un paso de rampa para mantener el contraste.

## Contenido

| Carpeta | Qué hay |
| --- | --- |
| `tokens/` | `tokens.css` (claro), `tokens.dark.css` (oscuro), `tokens.json`, `tokens.scss`, `tailwind.preset.js` |
| `js/` | `theme.js` — conmutador claro/oscuro con memoria |
| `css/` | `accordio.css` (nav, botones, tarjetas, etiquetas, campos, digitación, rating, filas, mástil, rejilla), `fonts.css` |
| `logo/` | lockup horizontal (claro/oscuro), lockup G apilado, marca diagrama (3 versiones), marca G, icono de app, favicon |
| `icons/` | 23 iconos SVG de 24 px + `sprite.svg` + guía de uso |
| `icons-dark/` | los mismos 23 iconos con color por defecto claro (para usar como `<img>` en oscuro) |
| `chords/` | diagramas de acordes SVG (G, C, D, Em, Am) + plantilla vacía, en claro y `-dark` |
| `patterns/` | `music-tile.svg` (mosaico), versión transparente y `hero-band.svg`, cada uno con su `-dark` |
| `images/` | ilustración del guitarrista, avatar, muestra de partitura/tab y 3 capturas de referencia |
| `guide/` | guía visual navegable, con conmutador de tema |

## Paleta

| Rol | Hex | Uso |
| --- | --- | --- |
| Primary | `#1A535C` | barra superior, titulares, trazo de diagramas, acción principal |
| Coral | `#FF6B6B` | acción destacada, «nuevo», acentos de icono |
| Turquoise | `#4ECDC4` | estado activo/seleccionado, confirmación |
| Yellow | `#FFE66D` | pendiente de revisión, estrellas de valoración |
| Cream | `#F7EFE3` | fondo de página (con el mosaico de notas) |
| Surface | `#F2FAF6` | tarjetas |
| Ink / Body | `#12363D` / `#3F5257` | titulares / texto corrido |

Cada rol trae rampa 100–900 (`--ac-primary-300`, `--ac-coral-700`…): 100–300 para rellenos
tintados y hovers, 500 base, 700–900 para texto sobre relleno tintado.

## Reglas

1. **Un solo acento por bloque.** Coral y turquesa no compiten en el mismo componente: coral
   para llamar a la acción, turquesa para indicar estado.
2. **Amarillo solo es estado**, nunca decoración: valoración y «awaiting review».
3. **Nada cuadrado.** Controles 12 px, tarjetas 20 px, icono de app 22 %. El único elemento
   recto es el diagrama de acordes.
4. **Titulares Montserrat 700/800** con tracking −0.02 em; texto Poppins 400/500. No mezclar.
5. **Texto corrido sobre coral o amarillo, jamás.** Usar `--ac-coral-700` / `--ac-yellow-900`.
6. **El mosaico de notas va solo en el fondo de página** (crema en claro, night en oscuro) y tal
   cual está: no tintarlo ni superponerlo a tarjetas.
7. **Diagramas de acordes**: trazo 2.6 px en `--ac-primary`, cejilla 6 px, puntos rellenos con
   el número de dedo en `--ac-surface`, cuerdas al aire con círculo hueco arriba.
8. **Foco visible siempre**: `outline: 3px solid var(--ac-focus)` — ya está en `accordio.css`.
9. **Nunca fijes un color a mano si existe rol.** Usa `--ac-action` / `--ac-on-action`,
   `--ac-highlight` / `--ac-on-highlight`, `--ac-nav-bg` / `--ac-nav-fg` y `--ac-icon-color`: son
   los que cambian con el tema. `--ac-primary` y compañía siguen siendo la marca, no el rol.

## Notas

- Los logotipos usan texto con `font-family: Montserrat`. Si necesitas independencia total de
  fuentes (impresión, email), convierte el texto a trazados en tu editor vectorial.
- `images/` sale del board de referencia y está a resolución media: sirve para maquetar y para
  placeholders. Sustitúyelas por material definitivo antes de publicar.
