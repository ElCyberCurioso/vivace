/* Tailwind preset — Accordio */
module.exports = {
  darkMode: ['class', '[data-theme="dark"]'],
  theme: {
    extend: {
      colors: {
        primary: { DEFAULT:'#1A535C',100:'#E3EEF0',200:'#BCD6DA',300:'#8DB6BD',400:'#4E8A94',500:'#1A535C',600:'#154650',700:'#113941',800:'#0D2B31',900:'#081D21' },
        coral:   { DEFAULT:'#FF6B6B',100:'#FFE9E9',200:'#FFCCCC',300:'#FFA8A8',400:'#FF8888',500:'#FF6B6B',600:'#EE5253',700:'#C93B3C',800:'#9E2B2C',900:'#701F1F' },
        turquoise:{DEFAULT:'#4ECDC4',100:'#E6F9F7',200:'#C2F0EB',300:'#94E4DD',400:'#6DD9D0',500:'#4ECDC4',600:'#37AFA6',700:'#2A8A83',800:'#1F6660',900:'#164742' },
        yellow:  { DEFAULT:'#FFE66D',100:'#FFFBE6',200:'#FFF6C4',300:'#FFF09E',400:'#FFEA82',500:'#FFE66D',600:'#F2CE3D',700:'#C9A317',800:'#96780F',900:'#6B550A' },
        cream:'#F7EFE3', 'cream-warm':'#F3E3CD', surface:'#F2FAF6', ink:'#12363D', bodytext:'#3F5257', muted:'#7B8E92', line:'#DCE8E5', fretboard:'#6B4226',
        night:'#0F2429', 'night-alt':'#122E34', 'surface-dark':'#163A41', 'surface-dark-2':'#1C464E', 'ink-dark':'#F2FAF6', 'bodytext-dark':'#C6DCDE', 'muted-dark':'#8CA6AA', 'line-dark':'#26545C'
      },
      fontFamily: { heading:['Montserrat','system-ui','sans-serif'], body:['Poppins','system-ui','sans-serif'] },
      borderRadius: { sm:'8px', md:'12px', lg:'20px', xl:'28px', pill:'999px' },
      boxShadow: {
        sm:'0 1px 2px rgba(18,54,61,.06), 0 2px 6px rgba(18,54,61,.05)',
        md:'0 4px 10px rgba(18,54,61,.07), 0 12px 28px rgba(18,54,61,.07)',
        lg:'0 10px 24px rgba(18,54,61,.10), 0 28px 60px rgba(18,54,61,.10)'
      }
    }
  }
};
