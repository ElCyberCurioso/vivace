/* Accordio — conmutador de tema
   Uso:
     <script src="accordio-web-kit/js/theme.js"></script>          (en <head>, sin defer)
     <button data-ac-theme-toggle>Tema</button>
   Guarda la elección en localStorage('ac-theme'); sin elección sigue al sistema.
   Los recursos con dos versiones se declaran en el propio elemento:
     <img data-ac-light="../logo/lockup-horizontal.svg" data-ac-dark="../logo/lockup-horizontal-light.svg"> */
(function(){
  var KEY='ac-theme';
  function stored(){ try{ return localStorage.getItem(KEY); }catch(e){ return null; } }
  function system(){ return matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'; }
  function current(){ return stored() || system(); }
  function swapAssets(mode){
    document.querySelectorAll('[data-ac-light][data-ac-dark]').forEach(function(el){
      var src = el.getAttribute(mode === 'dark' ? 'data-ac-dark' : 'data-ac-light');
      if (el.tagName === 'IMG' || el.tagName === 'LINK') el[el.tagName==='IMG'?'src':'href'] = src;
      else el.style.backgroundImage = 'url("' + src + '")';
    });
  }
  function apply(mode){
    document.documentElement.setAttribute('data-theme', mode);
    document.documentElement.style.colorScheme = mode;
    swapAssets(mode);
    document.dispatchEvent(new CustomEvent('ac-themechange',{detail:{mode:mode}}));
  }
  window.AccordioTheme = {
    get: current,
    set: function(mode){ try{ localStorage.setItem(KEY, mode); }catch(e){} apply(mode); },
    toggle: function(){ this.set(current() === 'dark' ? 'light' : 'dark'); },
    clear: function(){ try{ localStorage.removeItem(KEY); }catch(e){} apply(system()); }
  };
  apply(current());
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function(){ if(!stored()) apply(system()); });
  document.addEventListener('DOMContentLoaded', function(){
    swapAssets(current());
    document.querySelectorAll('[data-ac-theme-toggle]').forEach(function(b){
      b.addEventListener('click', function(){ window.AccordioTheme.toggle(); });
    });
  });
})();
